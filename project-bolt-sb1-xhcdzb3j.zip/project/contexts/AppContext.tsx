import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'creator' | 'player';
  avatar?: string;
}

export interface ClueStep {
  id: string;
  title: string;
  description: string;
  referenceImage: string;
  location?: string;
  hint?: string;
  order: number;
}

export interface Game {
  id: string;
  title: string;
  description: string;
  creatorId: string;
  creatorName: string;
  steps: ClueStep[];
  coverImage: string;
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: number; // minutes
  createdAt: string;
  isActive: boolean;
}

export interface GameProgress {
  gameId: string;
  userId: string;
  currentStep: number;
  completedSteps: string[];
  startedAt: string;
  completedAt?: string;
}

interface AppContextType {
  user: User | null;
  games: Game[];
  gameProgress: GameProgress[];
  isLoading: boolean;
  login: (email: string, password: string, role: 'creator' | 'player') => Promise<boolean>;
  logout: () => void;
  createGame: (game: Omit<Game, 'id' | 'creatorId' | 'creatorName' | 'createdAt'>) => void;
  startGame: (gameId: string) => void;
  completeStep: (gameId: string, stepId: string) => void;
  loadGames: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [games, setGames] = useState<Game[]>([]);
  const [gameProgress, setGameProgress] = useState<GameProgress[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUserData();
    loadGames();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadGames = async () => {
    try {
      const gamesData = await AsyncStorage.getItem('games');
      const progressData = await AsyncStorage.getItem('gameProgress');
      
      if (gamesData) {
        setGames(JSON.parse(gamesData));
      } else {
        // Initialize with sample games
        const sampleGames: Game[] = [
          {
            id: '1',
            title: 'Paris Hidden Treasures',
            description: 'Discover the secret spots of Paris through this exciting treasure hunt!',
            creatorId: 'creator1',
            creatorName: 'Marie Dubois',
            coverImage: 'https://images.pexels.com/photos/161853/paris-france-tower-eiffel-161853.jpeg',
            difficulty: 'medium',
            estimatedTime: 120,
            createdAt: new Date().toISOString(),
            isActive: true,
            steps: [
              {
                id: 'step1',
                title: 'The Iron Lady',
                description: 'Find the famous iron structure that overlooks the city',
                referenceImage: 'https://images.pexels.com/photos/699466/pexels-photo-699466.jpeg',
                hint: 'Look for the tallest structure in the 7th arrondissement',
                order: 1
              },
              {
                id: 'step2',
                title: 'Glass Pyramid',
                description: 'Locate the modern glass entrance to a world-famous museum',
                referenceImage: 'https://images.pexels.com/photos/2363/france-landmark-lights-night.jpg',
                hint: 'Where Mona Lisa smiles behind glass walls',
                order: 2
              }
            ]
          },
          {
            id: '2',
            title: 'Urban Street Art Quest',
            description: 'Follow the trail of amazing street art across the city',
            creatorId: 'creator2',
            creatorName: 'Alex Johnson',
            coverImage: 'https://images.pexels.com/photos/1646953/pexels-photo-1646953.jpeg',
            difficulty: 'easy',
            estimatedTime: 90,
            createdAt: new Date().toISOString(),
            isActive: true,
            steps: [
              {
                id: 'step1',
                title: 'Colorful Mural',
                description: 'Find the vibrant mural depicting ocean life',
                referenceImage: 'https://images.pexels.com/photos/1194420/pexels-photo-1194420.jpeg',
                hint: 'Near the old fish market district',
                order: 1
              }
            ]
          }
        ];
        setGames(sampleGames);
        await AsyncStorage.setItem('games', JSON.stringify(sampleGames));
      }
      
      if (progressData) {
        setGameProgress(JSON.parse(progressData));
      }
    } catch (error) {
      console.error('Error loading games:', error);
    }
  };

  const login = async (email: string, password: string, role: 'creator' | 'player'): Promise<boolean> => {
    try {
      // Simulate authentication
      const newUser: User = {
        id: Date.now().toString(),
        email,
        name: email.split('@')[0],
        role
      };
      
      setUser(newUser);
      await AsyncStorage.setItem('user', JSON.stringify(newUser));
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = async () => {
    try {
      setUser(null);
      await AsyncStorage.removeItem('user');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const createGame = async (gameData: Omit<Game, 'id' | 'creatorId' | 'creatorName' | 'createdAt'>) => {
    if (!user) return;

    const newGame: Game = {
      ...gameData,
      id: Date.now().toString(),
      creatorId: user.id,
      creatorName: user.name,
      createdAt: new Date().toISOString()
    };

    const updatedGames = [...games, newGame];
    setGames(updatedGames);
    await AsyncStorage.setItem('games', JSON.stringify(updatedGames));
  };

  const startGame = async (gameId: string) => {
    if (!user) return;

    const newProgress: GameProgress = {
      gameId,
      userId: user.id,
      currentStep: 0,
      completedSteps: [],
      startedAt: new Date().toISOString()
    };

    const updatedProgress = [...gameProgress, newProgress];
    setGameProgress(updatedProgress);
    await AsyncStorage.setItem('gameProgress', JSON.stringify(updatedProgress));
  };

  const completeStep = async (gameId: string, stepId: string) => {
    if (!user) return;

    const updatedProgress = gameProgress.map(progress => {
      if (progress.gameId === gameId && progress.userId === user.id) {
        const completedSteps = [...progress.completedSteps, stepId];
        const game = games.find(g => g.id === gameId);
        const currentStep = progress.currentStep + 1;
        const isCompleted = game && currentStep >= game.steps.length;

        return {
          ...progress,
          completedSteps,
          currentStep,
          completedAt: isCompleted ? new Date().toISOString() : progress.completedAt
        };
      }
      return progress;
    });

    setGameProgress(updatedProgress);
    await AsyncStorage.setItem('gameProgress', JSON.stringify(updatedProgress));
  };

  return (
    <AppContext.Provider value={{
      user,
      games,
      gameProgress,
      isLoading,
      login,
      logout,
      createGame,
      startGame,
      completeStep,
      loadGames
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
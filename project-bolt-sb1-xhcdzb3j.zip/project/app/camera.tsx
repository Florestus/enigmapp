import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
  Modal,
  Image,
} from 'react-native';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { Camera, RotateCcw, X, Check } from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useApp } from '@/contexts/AppContext';

const COLORS = {
  primary: '#212937',
  accent: '#E8C698',
  white: '#FFFFFF',
  gray: '#6B7280',
  lightGray: '#F3F4F6',
  success: '#10B981',
  error: '#EF4444',
};

export default function CameraScreen() {
  const { gameId, stepId } = useLocalSearchParams<{ gameId: string; stepId: string }>();
  const { games, completeStep } = useApp();
  const [facing, setFacing] = useState<CameraType>('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [showResult, setShowResult] = useState(false);
  const [isMatch, setIsMatch] = useState(false);
  const [currentClue, setCurrentClue] = useState<any>(null);
  const cameraRef = useRef<CameraView>(null);

  const game = games.find(g => g.id === gameId);
  const step = game?.steps.find(s => s.id === stepId);

  if (!permission) {
    return <View style={styles.container} />;
  }

  if (!permission.granted) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.permissionContainer}>
          <Camera size={64} color={COLORS.gray} />
          <Text style={styles.permissionTitle}>Camera Permission Required</Text>
          <Text style={styles.permissionMessage}>
            We need access to your camera to scan for clues in the treasure hunt.
          </Text>
          <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
            <Text style={styles.permissionButtonText}>Grant Permission</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const toggleCameraFacing = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        // Simulate photo capture and matching
        const matchResult = Math.random() > 0.3; // 70% chance of match for demo
        setIsMatch(matchResult);
        setCurrentClue(step);
        setShowResult(true);
        
        if (matchResult && stepId) {
          completeStep(gameId!, stepId);
        }
      } catch (error) {
        Alert.alert('Error', 'Failed to take picture');
      }
    }
  };

  const handleClose = () => {
    router.back();
  };

  const handleContinue = () => {
    setShowResult(false);
    if (isMatch) {
      router.back();
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <CameraView ref={cameraRef} style={styles.camera} facing={facing}>
        <View style={styles.overlay}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.headerButton} onPress={handleClose}>
              <X size={24} color={COLORS.white} />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Scan for Clues</Text>
            <TouchableOpacity style={styles.headerButton} onPress={toggleCameraFacing}>
              <RotateCcw size={24} color={COLORS.white} />
            </TouchableOpacity>
          </View>

          {step && (
            <View style={styles.clueInfo}>
              <Text style={styles.clueTitle}>{step.title}</Text>
              <Text style={styles.clueDescription}>{step.description}</Text>
            </View>
          )}

          <View style={styles.scanArea}>
            <View style={styles.scanFrame} />
          </View>

          <View style={styles.footer}>
            <TouchableOpacity style={styles.captureButton} onPress={takePicture}>
              <View style={styles.captureButtonInner}>
                <Camera size={32} color={COLORS.primary} />
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </CameraView>

      {/* Result Modal */}
      <Modal
        visible={showResult}
        transparent
        animationType="fade"
        onRequestClose={() => setShowResult(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.resultModal}>
            <View style={[styles.resultIcon, isMatch ? styles.successIcon : styles.errorIcon]}>
              {isMatch ? (
                <Check size={32} color={COLORS.white} />
              ) : (
                <X size={32} color={COLORS.white} />
              )}
            </View>

            <Text style={styles.resultTitle}>
              {isMatch ? 'Perfect Match!' : 'Not Quite Right'}
            </Text>

            <Text style={styles.resultMessage}>
              {isMatch 
                ? 'You found the right location! Here\'s your next clue.'
                : 'This doesn\'t match what we\'re looking for. Try a different angle or location.'
              }
            </Text>

            {isMatch && currentClue?.hint && (
              <View style={styles.hintContainer}>
                <Text style={styles.hintTitle}>Next Clue:</Text>
                <Text style={styles.hintText}>{currentClue.hint}</Text>
              </View>
            )}

            <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
              <Text style={styles.continueButtonText}>
                {isMatch ? 'Continue Adventure' : 'Try Again'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.primary,
  },
  camera: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(33, 41, 55, 0.8)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.white,
  },
  clueInfo: {
    backgroundColor: 'rgba(33, 41, 55, 0.9)',
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  clueTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.white,
    marginBottom: 4,
  },
  clueDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.accent,
    lineHeight: 20,
  },
  scanArea: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanFrame: {
    width: 250,
    height: 250,
    borderWidth: 2,
    borderColor: COLORS.accent,
    borderRadius: 12,
    backgroundColor: 'transparent',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 50,
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.white,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  captureButtonInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  permissionContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  permissionTitle: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginTop: 24,
    marginBottom: 16,
    textAlign: 'center',
  },
  permissionMessage: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  permissionButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  permissionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  resultModal: {
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    width: '100%',
    maxWidth: 340,
  },
  resultIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  successIcon: {
    backgroundColor: COLORS.success,
  },
  errorIcon: {
    backgroundColor: COLORS.error,
  },
  resultTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 8,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  hintContainer: {
    backgroundColor: COLORS.lightGray,
    padding: 16,
    borderRadius: 12,
    width: '100%',
    marginBottom: 20,
  },
  hintTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  hintText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 20,
  },
  continueButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
    width: '100%',
  },
  continueButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
    textAlign: 'center',
  },
});
import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  Alert,
  Image,
} from 'react-native';
import { ArrowLeft, Plus, X, Image as ImageIcon, Save } from 'lucide-react-native';
import { router } from 'expo-router';
import { useApp } from '@/contexts/AppContext';
import * as ImagePicker from 'expo-image-picker';

const COLORS = {
  primary: '#212937',
  accent: '#E8C698',
  white: '#FFFFFF',
  gray: '#6B7280',
  lightGray: '#F3F4F6',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

interface ClueStep {
  id: string;
  title: string;
  description: string;
  referenceImage: string;
  hint: string;
  order: number;
}

export default function CreateGameScreen() {
  const { createGame } = useApp();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [estimatedTime, setEstimatedTime] = useState('60');
  const [coverImage, setCoverImage] = useState('');
  const [steps, setSteps] = useState<ClueStep[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleBack = () => {
    if (title || description || steps.length > 0) {
      Alert.alert(
        'Discard Changes',
        'Are you sure you want to discard your changes?',
        [
          { text: 'Keep Editing', style: 'cancel' },
          { text: 'Discard', style: 'destructive', onPress: () => router.back() }
        ]
      );
    } else {
      router.back();
    }
  };

  const pickCoverImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8,
    });

    if (!result.canceled) {
      setCoverImage(result.assets[0].uri);
    }
  };

  const addStep = () => {
    const newStep: ClueStep = {
      id: Date.now().toString(),
      title: '',
      description: '',
      referenceImage: '',
      hint: '',
      order: steps.length,
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (stepId: string, field: keyof ClueStep, value: string) => {
    setSteps(steps.map(step => 
      step.id === stepId ? { ...step, [field]: value } : step
    ));
  };

  const removeStep = (stepId: string) => {
    setSteps(steps.filter(step => step.id !== stepId));
  };

  const pickStepImage = async (stepId: string) => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled) {
      updateStep(stepId, 'referenceImage', result.assets[0].uri);
    }
  };

  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a game title');
      return;
    }

    if (!description.trim()) {
      Alert.alert('Error', 'Please enter a game description');
      return;
    }

    if (steps.length === 0) {
      Alert.alert('Error', 'Please add at least one step');
      return;
    }

    const incompleteSteps = steps.filter(step => 
      !step.title.trim() || !step.description.trim() || !step.referenceImage
    );

    if (incompleteSteps.length > 0) {
      Alert.alert('Error', 'Please complete all steps with title, description, and reference image');
      return;
    }

    setIsLoading(true);

    try {
      const gameData = {
        title: title.trim(),
        description: description.trim(),
        difficulty,
        estimatedTime: parseInt(estimatedTime) || 60,
        coverImage: coverImage || 'https://images.pexels.com/photos/1671324/pexels-photo-1671324.jpeg',
        steps: steps.map((step, index) => ({ ...step, order: index })),
        isActive: true,
      };

      createGame(gameData);
      
      Alert.alert(
        'Success',
        'Your treasure hunt has been created successfully!',
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to create game. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <ArrowLeft size={24} color={COLORS.primary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Create Game</Text>
        <TouchableOpacity 
          style={[styles.saveButton, isLoading && styles.disabledButton]} 
          onPress={handleSave}
          disabled={isLoading}
        >
          <Save size={20} color={COLORS.white} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Basic Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Basic Information</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Game Title</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter a catchy title..."
              placeholderTextColor={COLORS.gray}
              value={title}
              onChangeText={setTitle}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Describe your treasure hunt adventure..."
              placeholderTextColor={COLORS.gray}
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={3}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Estimated Time (minutes)</Text>
            <TextInput
              style={styles.input}
              placeholder="60"
              placeholderTextColor={COLORS.gray}
              value={estimatedTime}
              onChangeText={setEstimatedTime}
              keyboardType="numeric"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Difficulty</Text>
            <View style={styles.difficultyButtons}>
              {(['easy', 'medium', 'hard'] as const).map((level) => (
                <TouchableOpacity
                  key={level}
                  style={[
                    styles.difficultyButton,
                    difficulty === level && styles.activeDifficultyButton
                  ]}
                  onPress={() => setDifficulty(level)}
                >
                  <Text style={[
                    styles.difficultyButtonText,
                    difficulty === level && styles.activeDifficultyButtonText
                  ]}>
                    {level.charAt(0).toUpperCase() + level.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Cover Image</Text>
            <TouchableOpacity style={styles.imagePickerButton} onPress={pickCoverImage}>
              {coverImage ? (
                <Image source={{ uri: coverImage }} style={styles.coverImagePreview} />
              ) : (
                <>
                  <ImageIcon size={32} color={COLORS.gray} />
                  <Text style={styles.imagePickerText}>Tap to select cover image</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Steps */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Adventure Steps</Text>
            <TouchableOpacity style={styles.addStepButton} onPress={addStep}>
              <Plus size={20} color={COLORS.white} />
            </TouchableOpacity>
          </View>

          {steps.map((step, index) => (
            <View key={step.id} style={styles.stepCard}>
              <View style={styles.stepHeader}>
                <Text style={styles.stepNumber}>Step {index + 1}</Text>
                <TouchableOpacity 
                  style={styles.removeStepButton}
                  onPress={() => removeStep(step.id)}
                >
                  <X size={16} color={COLORS.error} />
                </TouchableOpacity>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Title</Text>
                <TextInput
                  style={styles.input}
                  placeholder="What should players find?"
                  placeholderTextColor={COLORS.gray}
                  value={step.title}
                  onChangeText={(text) => updateStep(step.id, 'title', text)}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Describe the location or object to find..."
                  placeholderTextColor={COLORS.gray}
                  value={step.description}
                  onChangeText={(text) => updateStep(step.id, 'description', text)}
                  multiline
                  numberOfLines={2}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Reference Image</Text>
                <TouchableOpacity 
                  style={styles.imagePickerButton}
                  onPress={() => pickStepImage(step.id)}
                >
                  {step.referenceImage ? (
                    <Image source={{ uri: step.referenceImage }} style={styles.stepImagePreview} />
                  ) : (
                    <>
                      <ImageIcon size={24} color={COLORS.gray} />
                      <Text style={styles.imagePickerText}>Add reference image</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Hint for Next Step</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Give a clue for the next location..."
                  placeholderTextColor={COLORS.gray}
                  value={step.hint}
                  onChangeText={(text) => updateStep(step.id, 'hint', text)}
                />
              </View>
            </View>
          ))}

          {steps.length === 0 && (
            <View style={styles.emptySteps}>
              <Text style={styles.emptyStepsText}>No steps added yet</Text>
              <Text style={styles.emptyStepsSubtext}>Tap the + button to add your first step</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
  },
  saveButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabledButton: {
    opacity: 0.6,
  },
  content: {
    flex: 1,
  },
  section: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
  },
  addStepButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: COLORS.primary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.lightGray,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.primary,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  difficultyButtons: {
    flexDirection: 'row',
  },
  difficultyButton: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  activeDifficultyButton: {
    backgroundColor: COLORS.primary,
  },
  difficultyButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: COLORS.gray,
  },
  activeDifficultyButtonText: {
    color: COLORS.white,
  },
  imagePickerButton: {
    backgroundColor: COLORS.lightGray,
    borderRadius: 8,
    paddingVertical: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  imagePickerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginTop: 8,
  },
  coverImagePreview: {
    width: '100%',
    height: 120,
    borderRadius: 8,
    resizeMode: 'cover',
  },
  stepCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  stepNumber: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
  },
  removeStepButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepImagePreview: {
    width: '100%',
    height: 100,
    borderRadius: 8,
    resizeMode: 'cover',
  },
  emptySteps: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyStepsText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  emptyStepsSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
});
import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { Plus, Trophy, Clock, Star } from 'lucide-react-native';
import { useApp } from '@/contexts/AppContext';
import { router } from 'expo-router';

const COLORS = {
  primary: '#212937',
  accent: '#E8C698',
  white: '#FFFFFF',
  gray: '#6B7280',
  lightGray: '#F3F4F6',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

export default function CreateTab() {
  const { games, user } = useApp();
  
  const myGames = games.filter(game => game.creatorId === user?.id);
  const totalPlays = myGames.reduce((sum, game) => sum + (game.steps.length * 10), 0); // Mock play count

  const handleCreateNewGame = () => {
    router.push('/create-game');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return COLORS.success;
      case 'medium': return COLORS.warning;
      case 'hard': return COLORS.error;
      default: return COLORS.gray;
    }
  };

  const handleEditGame = (gameId: string) => {
    router.push({
      pathname: '/create-game',
      params: { gameId }
    });
  };

  const handleDeleteGame = (gameId: string, gameTitle: string) => {
    Alert.alert(
      'Delete Game',
      `Are you sure you want to delete "${gameTitle}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => {
          // In a real app, this would delete the game
          console.log('Delete game:', gameId);
        }}
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Creator Studio</Text>
        <Text style={styles.subtitle}>Manage your treasure hunts</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Trophy size={24} color={COLORS.accent} />
            <Text style={styles.statNumber}>{myGames.length}</Text>
            <Text style={styles.statLabel}>Games Created</Text>
          </View>
          <View style={styles.statCard}>
            <Star size={24} color={COLORS.accent} />
            <Text style={styles.statNumber}>{totalPlays}</Text>
            <Text style={styles.statLabel}>Total Plays</Text>
          </View>
        </View>

        {/* Create New Game Button */}
        <TouchableOpacity style={styles.createButton} onPress={handleCreateNewGame}>
          <Plus size={24} color={COLORS.white} />
          <Text style={styles.createButtonText}>Create New Game</Text>
        </TouchableOpacity>

        {/* My Games Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>My Games</Text>
          
          {myGames.length === 0 ? (
            <View style={styles.emptyState}>
              <Plus size={48} color={COLORS.gray} />
              <Text style={styles.emptyTitle}>No games created yet</Text>
              <Text style={styles.emptyDescription}>
                Create your first treasure hunt to get started!
              </Text>
            </View>
          ) : (
            <View style={styles.gamesList}>
              {myGames.map((game) => (
                <View key={game.id} style={styles.gameCard}>
                  <View style={styles.gameHeader}>
                    <View style={styles.gameInfo}>
                      <Text style={styles.gameTitle}>{game.title}</Text>
                      <Text style={styles.gameDescription} numberOfLines={2}>
                        {game.description}
                      </Text>
                    </View>
                    <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(game.difficulty) }]}>
                      <Text style={styles.difficultyText}>{game.difficulty}</Text>
                    </View>
                  </View>

                  <View style={styles.gameStats}>
                    <View style={styles.gameStat}>
                      <Clock size={16} color={COLORS.gray} />
                      <Text style={styles.gameStatText}>{game.estimatedTime} min</Text>
                    </View>
                    <View style={styles.gameStat}>
                      <Text style={styles.gameStatText}>{game.steps.length} steps</Text>
                    </View>
                    <View style={styles.gameStat}>
                      <Text style={[styles.gameStatText, { color: game.isActive ? COLORS.success : COLORS.error }]}>
                        {game.isActive ? 'Active' : 'Inactive'}
                      </Text>
                    </View>
                  </View>

                  <View style={styles.gameActions}>
                    <TouchableOpacity 
                      style={[styles.actionButton, styles.editButton]}
                      onPress={() => handleEditGame(game.id)}
                    >
                      <Text style={styles.editButtonText}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.actionButton, styles.deleteButton]}
                      onPress={() => handleDeleteGame(game.id, game.title)}
                    >
                      <Text style={styles.deleteButtonText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
  content: {
    flex: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.lightGray,
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginRight: 10,
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: COLORS.primary,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginTop: 4,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    marginHorizontal: 20,
    paddingVertical: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  createButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
    marginLeft: 8,
  },
  section: {
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    textAlign: 'center',
    lineHeight: 20,
  },
  gamesList: {
    paddingBottom: 20,
  },
  gameCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  gameInfo: {
    flex: 1,
    marginRight: 12,
  },
  gameTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  gameDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 18,
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: COLORS.white,
    textTransform: 'capitalize',
  },
  gameStats: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  gameStat: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  gameStatText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginLeft: 4,
  },
  gameActions: {
    flexDirection: 'row',
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  editButton: {
    backgroundColor: COLORS.lightGray,
  },
  deleteButton: {
    backgroundColor: COLORS.error,
  },
  editButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: COLORS.primary,
  },
  deleteButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: COLORS.white,
  },
});
import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  TextInput,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Search, Clock, Star, MapPin } from 'lucide-react-native';
import { useApp } from '@/contexts/AppContext';
import { router } from 'expo-router';

const COLORS = {
  primary: '#212937',
  accent: '#E8C698',
  white: '#FFFFFF',
  gray: '#6B7280',
  lightGray: '#F3F4F6',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

const { width } = Dimensions.get('window');

export default function PlayTab() {
  const { games, gameProgress, user, startGame } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredGames = games.filter(game =>
    game.isActive &&
    (game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
     game.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getUserProgress = (gameId: string) => {
    return gameProgress.find(p => p.gameId === gameId && p.userId === user?.id);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return COLORS.success;
      case 'medium': return COLORS.warning;
      case 'hard': return COLORS.error;
      default: return COLORS.gray;
    }
  };

  const handlePlayGame = (gameId: string) => {
    const progress = getUserProgress(gameId);
    if (!progress) {
      startGame(gameId);
    }
    router.push({
      pathname: '/game-detail',
      params: { gameId }
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Discover Adventures</Text>
        <Text style={styles.subtitle}>Find your next treasure hunt</Text>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color={COLORS.gray} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search games..."
          placeholderTextColor={COLORS.gray}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.gamesGrid}>
          {filteredGames.map((game) => {
            const progress = getUserProgress(game.id);
            const isStarted = !!progress;
            const isCompleted = progress?.completedAt;
            const completionPercentage = progress ? 
              (progress.completedSteps.length / game.steps.length) * 100 : 0;

            return (
              <TouchableOpacity
                key={game.id}
                style={styles.gameCard}
                onPress={() => handlePlayGame(game.id)}
                activeOpacity={0.9}
              >
                <Image source={{ uri: game.coverImage }} style={styles.gameImage} />
                
                <View style={styles.gameContent}>
                  <View style={styles.gameHeader}>
                    <Text style={styles.gameTitle} numberOfLines={2}>
                      {game.title}
                    </Text>
                    <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(game.difficulty) }]}>
                      <Text style={styles.difficultyText}>{game.difficulty}</Text>
                    </View>
                  </View>

                  <Text style={styles.gameDescription} numberOfLines={2}>
                    {game.description}
                  </Text>

                  <View style={styles.gameInfo}>
                    <View style={styles.infoItem}>
                      <Clock size={14} color={COLORS.gray} />
                      <Text style={styles.infoText}>{game.estimatedTime} min</Text>
                    </View>
                    <View style={styles.infoItem}>
                      <MapPin size={14} color={COLORS.gray} />
                      <Text style={styles.infoText}>{game.steps.length} stops</Text>
                    </View>
                  </View>

                  <View style={styles.creatorInfo}>
                    <Text style={styles.creatorText}>by {game.creatorName}</Text>
                  </View>

                  {isStarted && (
                    <View style={styles.progressContainer}>
                      <View style={styles.progressBar}>
                        <View 
                          style={[styles.progressFill, { width: `${completionPercentage}%` }]} 
                        />
                      </View>
                      <Text style={styles.progressText}>
                        {isCompleted ? 'Completed!' : `${Math.round(completionPercentage)}% complete`}
                      </Text>
                    </View>
                  )}

                  <TouchableOpacity 
                    style={[styles.playButton, isCompleted && styles.completedButton]}
                    onPress={() => handlePlayGame(game.id)}
                  >
                    <Text style={[styles.playButtonText, isCompleted && styles.completedButtonText]}>
                      {isCompleted ? 'View Results' : isStarted ? 'Continue' : 'Start Adventure'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {filteredGames.length === 0 && (
          <View style={styles.emptyState}>
            <Search size={48} color={COLORS.gray} />
            <Text style={styles.emptyTitle}>No games found</Text>
            <Text style={styles.emptyDescription}>
              {searchQuery ? 'Try adjusting your search terms' : 'Check back later for new adventures!'}
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.lightGray,
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 48,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.primary,
  },
  content: {
    flex: 1,
  },
  gamesGrid: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  gameCard: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    marginBottom: 20,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  gameImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
  },
  gameContent: {
    padding: 16,
  },
  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  gameTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    flex: 1,
    marginRight: 12,
  },
  difficultyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: COLORS.white,
    textTransform: 'capitalize',
  },
  gameDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 20,
    marginBottom: 12,
  },
  gameInfo: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  infoText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginLeft: 4,
  },
  creatorInfo: {
    marginBottom: 16,
  },
  creatorText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORS.lightGray,
    borderRadius: 2,
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.accent,
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: COLORS.gray,
  },
  playButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  completedButton: {
    backgroundColor: COLORS.success,
  },
  playButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
  },
  completedButtonText: {
    color: COLORS.white,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    textAlign: 'center',
    lineHeight: 20,
  },
});
import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';
import { ArrowLeft, Camera, MapPin, Clock, CircleCheck as CheckCircle } from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useApp } from '@/contexts/AppContext';

const COLORS = {
  primary: '#212937',
  accent: '#E8C698',
  white: '#FFFFFF',
  gray: '#6B7280',
  lightGray: '#F3F4F6',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

export default function GameDetailScreen() {
  const { gameId } = useLocalSearchParams<{ gameId: string }>();
  const { games, gameProgress, user } = useApp();

  const game = games.find(g => g.id === gameId);
  const progress = gameProgress.find(p => p.gameId === gameId && p.userId === user?.id);

  if (!game) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Game not found</Text>
      </SafeAreaView>
    );
  }

  const handleBack = () => {
    router.back();
  };

  const handleScanStep = (stepId: string) => {
    router.push({
      pathname: '/camera',
      params: { gameId: game.id, stepId }
    });
  };

  const isStepCompleted = (stepId: string) => {
    return progress?.completedSteps.includes(stepId) || false;
  };

  const isStepAccessible = (stepIndex: number) => {
    if (stepIndex === 0) return true;
    return progress?.completedSteps.includes(game.steps[stepIndex - 1].id) || false;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return COLORS.success;
      case 'medium': return COLORS.warning;
      case 'hard': return COLORS.error;
      default: return COLORS.gray;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <ArrowLeft size={24} color={COLORS.primary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Adventure Details</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Image source={{ uri: game.coverImage }} style={styles.coverImage} />
        
        <View style={styles.gameInfo}>
          <View style={styles.gameHeader}>
            <Text style={styles.gameTitle}>{game.title}</Text>
            <View style={[styles.difficultyBadge, { backgroundColor: getDifficultyColor(game.difficulty) }]}>
              <Text style={styles.difficultyText}>{game.difficulty}</Text>
            </View>
          </View>

          <Text style={styles.gameDescription}>{game.description}</Text>

          <View style={styles.gameStats}>
            <View style={styles.statItem}>
              <Clock size={16} color={COLORS.gray} />
              <Text style={styles.statText}>{game.estimatedTime} minutes</Text>
            </View>
            <View style={styles.statItem}>
              <MapPin size={16} color={COLORS.gray} />
              <Text style={styles.statText}>{game.steps.length} locations</Text>
            </View>
          </View>

          <Text style={styles.creatorInfo}>Created by {game.creatorName}</Text>

          {progress && (
            <View style={styles.progressSection}>
              <Text style={styles.progressTitle}>Your Progress</Text>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill, 
                    { width: `${(progress.completedSteps.length / game.steps.length) * 100}%` }
                  ]} 
                />
              </View>
              <Text style={styles.progressText}>
                {progress.completedSteps.length} of {game.steps.length} completed
              </Text>
            </View>
          )}
        </View>

        <View style={styles.stepsSection}>
          <Text style={styles.sectionTitle}>Adventure Steps</Text>
          
          {game.steps.map((step, index) => {
            const completed = isStepCompleted(step.id);
            const accessible = isStepAccessible(index);
            
            return (
              <View key={step.id} style={styles.stepCard}>
                <View style={styles.stepHeader}>
                  <View style={styles.stepNumber}>
                    {completed ? (
                      <CheckCircle size={20} color={COLORS.success} />
                    ) : (
                      <Text style={[styles.stepNumberText, !accessible && styles.disabledText]}>
                        {index + 1}
                      </Text>
                    )}
                  </View>
                  <View style={styles.stepInfo}>
                    <Text style={[styles.stepTitle, !accessible && styles.disabledText]}>
                      {step.title}
                    </Text>
                    <Text style={[styles.stepDescription, !accessible && styles.disabledText]}>
                      {step.description}
                    </Text>
                  </View>
                </View>

                {step.referenceImage && accessible && (
                  <Image source={{ uri: step.referenceImage }} style={styles.stepImage} />
                )}

                {accessible && !completed && (
                  <TouchableOpacity 
                    style={styles.scanButton}
                    onPress={() => handleScanStep(step.id)}
                  >
                    <Camera size={20} color={COLORS.white} />
                    <Text style={styles.scanButtonText}>Scan Location</Text>
                  </TouchableOpacity>
                )}

                {completed && step.hint && (
                  <View style={styles.hintContainer}>
                    <Text style={styles.hintTitle}>Next Clue:</Text>
                    <Text style={styles.hintText}>{step.hint}</Text>
                  </View>
                )}

                {!accessible && (
                  <View style={styles.lockedContainer}>
                    <Text style={styles.lockedText}>Complete previous step to unlock</Text>
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {progress?.completedAt && (
          <View style={styles.completionCard}>
            <CheckCircle size={32} color={COLORS.success} />
            <Text style={styles.completionTitle}>Adventure Completed!</Text>
            <Text style={styles.completionMessage}>
              Congratulations! You've successfully completed this treasure hunt.
            </Text>
            <Text style={styles.completionTime}>
              Completed on {new Date(progress.completedAt).toLocaleDateString()}
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  coverImage: {
    width: '100%',
    height: 250,
    resizeMode: 'cover',
  },
  gameInfo: {
    padding: 20,
  },
  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  gameTitle: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: COLORS.primary,
    flex: 1,
    marginRight: 12,
  },
  difficultyBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  difficultyText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
    textTransform: 'capitalize',
  },
  gameDescription: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 24,
    marginBottom: 16,
  },
  gameStats: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginLeft: 4,
  },
  creatorInfo: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    marginBottom: 20,
  },
  progressSection: {
    backgroundColor: COLORS.lightGray,
    padding: 16,
    borderRadius: 12,
  },
  progressTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  progressBar: {
    height: 6,
    backgroundColor: COLORS.white,
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.success,
    borderRadius: 3,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
  stepsSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 16,
  },
  stepCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.primary,
  },
  disabledText: {
    color: COLORS.gray,
  },
  stepInfo: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 20,
  },
  stepImage: {
    width: '100%',
    height: 120,
    borderRadius: 8,
    marginBottom: 12,
    resizeMode: 'cover',
  },
  scanButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 8,
  },
  scanButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.white,
    marginLeft: 8,
  },
  hintContainer: {
    backgroundColor: COLORS.lightGray,
    padding: 12,
    borderRadius: 8,
  },
  hintTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  hintText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
    lineHeight: 18,
  },
  lockedContainer: {
    backgroundColor: COLORS.lightGray,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  lockedText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.gray,
  },
  completionCard: {
    backgroundColor: COLORS.success,
    margin: 20,
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
  },
  completionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: COLORS.white,
    marginTop: 12,
    marginBottom: 8,
  },
  completionMessage: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: COLORS.white,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 8,
  },
  completionTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: COLORS.white,
    opacity: 0.8,
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: COLORS.error,
    textAlign: 'center',
    marginTop: 50,
  },
});